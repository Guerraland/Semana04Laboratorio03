package lab.supermercados;

public class Ventas {

    private int dia;
    private int monto_dia;

    public Ventas(int dia, int monto_dia) {
        this.dia = dia;
        this.monto_dia = monto_dia;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMonto_dia() {
        return monto_dia;
    }

    public void setMonto_dia(int monto_dia) {
        this.monto_dia = monto_dia;
    }

}
