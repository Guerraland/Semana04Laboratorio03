package lab.supermercados;

public class Locales {

    private String Nombre;
    private int Codigo;
    private String Nombre_G;
    private Ventas[] venta;
    
    public Locales(String Nombre, int Codigo, String Nombre_G, Ventas[] venta) {
        this.Nombre = Nombre;
        this.Codigo = Codigo;
        this.Nombre_G = Nombre_G;
        this.venta = venta;
    }

   
    public String ObtenerNombre(){
        return this.Nombre;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre_G() {
        return Nombre_G;
    }

    public void setNombre_G(String Nombre_G) {
        this.Nombre_G = Nombre_G;
    }

    public Ventas[] getVenta() {
        return venta;
    }

    public void setVenta(Ventas[] venta) {
        this.venta = venta;
    }

}
