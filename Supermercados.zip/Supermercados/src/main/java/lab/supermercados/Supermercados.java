package lab.supermercados;

import java.util.*;

public class Supermercados {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        Ventas[] ventas1 = new Ventas[7];
        Ventas[] ventas2 = new Ventas[7];
        Ventas[] ventas3 = new Ventas[7];
        double[] ventasxdia = new double[7];

        System.out.println("Bienvenido a la cadena de Supermercado afiliados");
        //SUPER1
        System.out.println("Datos del Supermercado 1:");
        System.out.println("Ingrea nombre del Supermercado: ");
        String Nombre1 = leer.nextLine();
        System.out.println("Codigo: ");
        int Codigo1 = leer.nextInt();
        leer.nextLine();
        System.out.println("Nombre del Gerente: ");
        String Nombre_G1 = leer.nextLine();
        //ventas_Super1_rep
        for (int i = 0; i < ventas1.length; i++) {
            System.out.println("Ingrese las ventas diarias del dia " + (i + 1) + ":");
            int monto_dia = leer.nextInt();
            ventas1[i] = new Ventas(i + 1, monto_dia);
            leer.nextLine();

        }
        Locales local1 = new Locales(Nombre1, Codigo1, Nombre_G1, ventas1);

        //SUPER2
        System.out.println("Datos del Supermercado 2:");
        System.out.println("Ingrea nombre del Supermercado: ");
        String Nombre2 = leer.nextLine();
        System.out.println("Codigo: ");
        int Codigo2 = leer.nextInt();
        leer.nextLine();
        System.out.println("Nombre del Gerente: ");
        String Nombre_G2 = leer.nextLine();
        //ventas_Super2_rep
        for (int i = 0; i < ventas2.length; i++) {
            System.out.println("Ingrese las ventas diarias del dia " + (i + 1) + ":");
            int monto_dia = leer.nextInt();
            ventas2[i] = new Ventas(i + 1, monto_dia);
            leer.nextLine();
        }
        Locales local2 = new Locales(Nombre2, Codigo2, Nombre_G2, ventas2);

        //SUPER3
        System.out.println("Datos del Supermercado 3:");
        System.out.println("Ingrea nombre del Supermercado: ");
        String Nombre3 = leer.nextLine();
        System.out.println("Codigo: ");
        int Codigo3 = leer.nextInt();
        leer.nextLine();
        System.out.println("Nombre del Gerente: ");
        String Nombre_G3 = leer.nextLine();
        //ventas_Super3_rep
        for (int i = 0; i < ventas3.length; i++) {
            System.out.println("Ingrese las ventas diarias del dia " + (i + 1) + ":");
            int monto_dia = leer.nextInt();
            ventas3[i] = new Ventas(i + 1, monto_dia);
            leer.nextLine();
        }
        Locales local3 = new Locales(Nombre3, Codigo3, Nombre_G3, ventas3);

        //ventas diaria
        int totalventas = 0;
        for (Ventas vent : local1.getVenta()) {
            totalventas += vent.getMonto_dia();
        }
        int totalventas1 = 0;
        for (Ventas vent : local2.getVenta()) {
            totalventas1 += vent.getMonto_dia();
        }
        int totalventas2 = 0;
        for (Ventas vent : local3.getVenta()) {
            totalventas2 += vent.getMonto_dia();
        }
        ///porcentajeV
        for (int s = 0; s < ventasxdia.length; s++) {
            double ventasxdia1 = local1.getVenta()[s].getMonto_dia();
            double ventasxdia2 = local2.getVenta()[s].getMonto_dia();
            double ventasxdia3 = local3.getVenta()[s].getMonto_dia();
            ventasxdia[s] = (ventasxdia1 + ventasxdia2 + ventasxdia3) / (totalventas + totalventas1 + totalventas2);
        }
        
        
        System.out.println("Registro de informacion de la cadena de Supermercados");
        System.out.println("Supermercado " + local1.getNombre() + " a vendido un total de: " + totalventas);
        System.out.println("Supermercado " + local2.getNombre() + " a vendido un total de: " + totalventas1);
        System.out.println("Supermercado " + local3.getNombre() + " a vendido un total de: " + totalventas2);
        System.out.println("Total de ventas de producto de los 3 Supermercado " + (totalventas1 + totalventas2 + totalventas));
        
        System.out.println("Porcentaje de ventas por dia de la cadena de Supermercado: ");
        for (int a = 0; a < ventasxdia.length; a++) {
            System.out.println("dia " + (a + 1) + ":" + (String.format(("%.2f"), (ventasxdia[a] * 100))) + "%");
        }
        //menor vendedor
        if (totalventas <= totalventas1 && totalventas <= totalventas2) {
            System.out.println("El supermecado " + local1.getNombre() + " fue el que menos a vendio productos");
        }
        if (totalventas1 <= totalventas && totalventas1 <= totalventas2) {
            System.out.println("El supermecado " + local2.getNombre() + " fue el que menos a vendio productos");
        }
        if (totalventas2 <= totalventas && totalventas2 <= totalventas1) {
            System.out.println("El supermecado " + local3.getNombre() + " fue el que menos a vendio productos");
        }
    }
}
